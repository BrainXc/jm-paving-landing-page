JM PAVING LANDING PAGE - FINAL

Hero is now a true full-width banner using the supplied hero artwork, matching the reference composition.
The About section has the Schedule Your Free Estimate blue card overlapping the driveway image as in the reference.
Open index.html or deploy the folder to Vercel as a static site.
